package coms.SpringBootJdbcApp.beans;
/*
 * Create table Person_info(perid  int auto_increment primary key, 
person_name varchar(20), 
email varchar(50), pswd varchar(20), phone varchar(10));
 */

public class Person {
	private int perid;
	private String person_name;
	private String email, pswd, phone;
	
	public int getPerid() {
		return perid;
	}
	public void setPerid(int perid) {
		this.perid = perid;
	}
	public String getPerson_name() {
		return person_name;
	}
	public void setPerson_name(String person_name) {
		this.person_name = person_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPswd() {
		return pswd;
	}
	public void setPswd(String pswd) {
		this.pswd = pswd;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
