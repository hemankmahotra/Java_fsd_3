package coms.SpringBootJdbcApp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import coms.SpringBootJdbcApp.beans.Person;
import coms.SpringBootJdbcApp.service.PersonService;

@Controller
public class LoginController {

	@Autowired
	PersonService ps;
	
	@GetMapping("/")
	public String LandingPage(Model m) // home page opens
	{
		return "LoginPage";
	}
	
	@GetMapping("/login")
	public String LoginPage(Model m)
	{
		return "LoginPage";
	}
	@PostMapping("/loginProcess")
	public String LoginPage(@RequestParam String txtUser,
			@RequestParam String txtPass,
			Model m)
	{
		System.out.println(txtUser + "  " + txtPass);
		if(txtUser.equals("Admin") && txtPass.equals("admin@123"))
		{
			return "redirect:/vall";
		}
		
		Person  p = ps.LoginCheck(txtUser, txtPass);
		
		System.out.println(p.getEmail() + "  "  + p.getPswd());
		if(p!=null)
		{
			m.addAttribute("pinfo", p);
			return "WelcomePage";
		}
		m.addAttribute("info", "Please check username/password");
		return "LoginPage";
	}
	
	@GetMapping("/cpwd/{pid}")
	public String ChangePassword(@PathVariable int pid, Model m)
	{
		m.addAttribute("pid", pid);
		return "ChangePwd";
	}
	
	@PostMapping("/chpwd")
	public String ChangePassword(@RequestParam String txtNpwd,
			@RequestParam String txtCNpwd, 
			@RequestParam String txtPid, Model m)
	{
		//System.out.println(txtPid);
		//System.out.println(txtNpwd  + "\t" + txtCNpwd);
		if(txtNpwd.equals(txtCNpwd))
		{
			ps.ChangePassword(txtCNpwd,Integer.parseInt(txtPid));
			return "LoginPage";
		}
		m.addAttribute("msg", "Both Passwords must be same");
		return "ChangePwd";
	}
}
