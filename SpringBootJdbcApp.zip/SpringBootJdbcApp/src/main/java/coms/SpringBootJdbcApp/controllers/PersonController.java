package coms.SpringBootJdbcApp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import coms.SpringBootJdbcApp.beans.Person;
import coms.SpringBootJdbcApp.service.PersonService;

@Controller
public class PersonController {
	
	@Autowired
	PersonService ps;
	
	@GetMapping("/nperson")
	public String AddPerson(Model m)
	{
		m.addAttribute("person", new Person());
		return "AddPerson";
	}
	
	@PostMapping("/npersonform")
	public String AddPerson(@ModelAttribute Person person,   Model m)
	{
		String str = ps.AddPerson(person);
		if(str.equals("Success"))
			m.addAttribute("info", "Person Added....");
		
		m.addAttribute("person", new Person());
		return "redirect:/vall";
	}
	
	@GetMapping("/vall")
	public String ViewAllPersons(Model m)
	{
		List<Person>  plist = ps.ViewAll();
		m.addAttribute("plist", plist);
		return "ViewAllPersons";
	}
	
	
	@GetMapping("/mperson/{pid}")
	public String UpdatePerson(@PathVariable int pid,  Model m)
	{
		Person per = ps.SearchPerson(pid);
		m.addAttribute("per", per);
		return "ModifyPerson";
	}
	
	@PostMapping("/updateperson")
	public String ModifyPerson(@ModelAttribute Person per, Model m)
	{
		ps.UpdatePerson(per);
		return "redirect:/vall";
	}
	
	@GetMapping("/delperson/{pid}")
	public String DeletePerson(@PathVariable int pid, Model m)
	{
		ps.DeletePerson(pid);
		return "redirect:/vall";
	}
	
}
