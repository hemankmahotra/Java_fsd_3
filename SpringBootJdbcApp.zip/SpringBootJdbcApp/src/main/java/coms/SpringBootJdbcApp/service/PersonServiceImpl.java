package coms.SpringBootJdbcApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import coms.SpringBootJdbcApp.beans.Person;

@Service
public class PersonServiceImpl implements PersonService {

	@Autowired
	JdbcTemplate jdbc;
		
	@Override
	public String AddPerson(Person person) {
		String sqlcmd = "Insert into Person_info(perid, person_name, email, pswd, phone) values(?,?,?,?,?)";
		int res = jdbc.update(sqlcmd, new Object[] {person.getPerid(), person.getPerson_name(), person.getEmail(), person.getPswd(), person.getPhone()});
		if(res>=1)
			return "Success";;
		return "err";
	}

	@Override
	public List<Person> ViewAll() {
		String sql = "Select * from person_info";
		List<Person>  personlist = jdbc.query(sql, new BeanPropertyRowMapper(Person.class));
		return  personlist;
	}

	@Override
	public Person SearchPerson(int pid) {
		String sql = "Select * from person_info where perid=?";
		Person person = null;
		
		try
		{
			person = (Person)jdbc.queryForObject(sql, new Object[] {pid}, new BeanPropertyRowMapper(Person.class));
		}
		catch(Exception ex)
		{
			person = null;
		}
		return person;
	}

	@Override
	public String UpdatePerson(Person person) {
		String sqlcmd = "update Person_info set person_name=?, email=?, pswd=?, phone=? where perid=?";
		int res = jdbc.update(sqlcmd, new Object[] {person.getPerson_name(), person.getEmail(), person.getPswd(), person.getPhone(), person.getPerid()});
		if(res>=1)
			return "Success";;
		return "err";
	}

	@Override
	public String DeletePerson(int pid) {
		String sqlcmd = "Delete from person_info where perid=?";
		int res = jdbc.update(sqlcmd, new Object[] {pid});
		if(res>=1)
			return "Success";;
		return "err";
	}

	@Override
	public Person LoginCheck(String uname, String pwd) {
		
		String sql = "Select * from person_info where email=? and pswd=?";
		Person person = null;
		try
		{
			person = (Person)jdbc.queryForObject(sql, new Object[] {uname, pwd}, new BeanPropertyRowMapper(Person.class));
		}
		catch(Exception ex)
		{
			person = null;
		}
		return person;
	}

	@Override
	public String ChangePassword(String npwd, int pid) {
		String sqlcmd = "update Person_info set pswd=? where perid=?";
		int res = jdbc.update(sqlcmd, new Object[] {npwd, pid});
		if(res>=1)
			return "Success";;
		return "err";
	}
}
