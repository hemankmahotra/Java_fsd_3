package coms.SpringBootJdbcApp.service;
import java.util.List;

import coms.SpringBootJdbcApp.beans.*;

public interface PersonService {

	public String AddPerson(Person person);
	public List<Person> ViewAll();
	public Person SearchPerson(int pid);
	public String UpdatePerson(Person person);
	public String DeletePerson(int pid);
	public Person LoginCheck(String uname, String pwd);
	public String ChangePassword(String npwd, int pid);
}
